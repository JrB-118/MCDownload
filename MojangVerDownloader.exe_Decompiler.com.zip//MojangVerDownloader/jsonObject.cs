namespace MojangVerDownloader
{
	public class jsonObject
	{
		public string id
		{
			get;
			set;
		}

		public string type
		{
			get;
			set;
		}

		public string url
		{
			get;
			set;
		}
	}
}
