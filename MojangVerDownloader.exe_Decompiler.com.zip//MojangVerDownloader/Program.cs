using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MojangVerDownloader
{
	internal class Program
	{
		public static string mojangData = "http://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

		public static string fileSha1;

		public static string versionUrl;

		private static void Main(string[] args)
		{
			Start();
		}

		public static void Start()
		{
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			Console.set_Title("Mojang Version Downloader v1.1");
			Console.WriteLine("Mojang Version Downloader v1.1");
			Console.WriteLine("by DEJVOSS Productions");
			Console.WriteLine("------------------------------");
			foreach (JProperty item in JsonConvert.DeserializeObject<JObject>(new WebClient().DownloadString(mojangData)).Properties())
			{
				string name = item.get_Name();
				string text = ((object)item.get_Value()).ToString();
				if (name == "latest")
				{
					foreach (JProperty item2 in JsonConvert.DeserializeObject<JObject>(text).Properties())
					{
						string name2 = item2.get_Name();
						string str = ((object)item2.get_Value()).ToString();
						Console.WriteLine("Latest " + name2 + " is " + str);
					}
					Console.Write("------------------------------");
				}
				else
				{
					if (!(name == "versions"))
					{
						continue;
					}
					foreach (jsonObject item3 in JsonConvert.DeserializeObject<List<jsonObject>>(text))
					{
						string text2 = item3.url;
						if (text2.LastIndexOf("/") >= 0)
						{
							text2 = text2.Substring(text2.LastIndexOf("/") + 1);
						}
						string verName = text2.Substring(0, text2.Length - 5);
						Console.set_ForegroundColor((ConsoleColor)11);
						Console.WriteLine("\n" + item3.id + " (" + item3.type + ")");
						Console.set_ForegroundColor((ConsoleColor)7);
						versionJson(item3.url, item3.type, verName);
					}
					Console.WriteLine("------------------------------");
					Console.WriteLine("Finished!");
					Console.WriteLine("------------------------------");
				}
			}
			Console.ReadLine();
		}

		public static void versionJson(string url, string category, string verName)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			foreach (JProperty item in JsonConvert.DeserializeObject<JObject>(new WebClient().DownloadString(url)).Properties())
			{
				string name = item.get_Name();
				string text = ((object)item.get_Value()).ToString();
				if (!(name == "downloads"))
				{
					continue;
				}
				foreach (JProperty item2 in JsonConvert.DeserializeObject<JObject>(text).Properties())
				{
					string name2 = item2.get_Name();
					foreach (JProperty item3 in JsonConvert.DeserializeObject<JObject>(((object)item2.get_Value()).ToString()).Properties())
					{
						string name3 = item3.get_Name();
						string text2 = ((object)item3.get_Value()).ToString();
						if (name3 == "url")
						{
							versionUrl = ((object)item3.get_Value()).ToString();
						}
						else if (name3 == "sha1")
						{
							fileSha1 = text2;
						}
					}
					Console.WriteLine(versionUrl ?? "");
					switch (name2)
					{
					case "client":
						downloadFile("downloads\\" + category + "\\" + verName, versionUrl, "client.jar", fileSha1, verName);
						break;
					case "server":
						downloadFile("downloads\\" + category + "\\" + verName, versionUrl, "server.jar", fileSha1, verName);
						break;
					case "windows_server":
						downloadFile("downloads\\" + category + "\\" + verName, versionUrl, "windows_server.exe", fileSha1, verName);
						break;
					case "client_mappings":
						downloadFile("downloads\\" + category + "\\" + verName, versionUrl, "client.txt", fileSha1, verName);
						break;
					case "server_mappings":
						downloadFile("downloads\\" + category + "\\" + verName, versionUrl, "server.txt", fileSha1, verName);
						break;
					default:
						Console.WriteLine("Unknown type!");
						break;
					}
				}
			}
		}

		public static void downloadFile(string dir, string url, string fileName, string fileHash, string verName)
		{
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Expected O, but got Unknown
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Expected O, but got Unknown
			if (!File.Exists(dir + "\\" + fileName))
			{
				Directory.CreateDirectory(dir);
				WebClient val = new WebClient();
				try
				{
					val.DownloadFile(url, dir + "\\" + fileName);
				}
				finally
				{
					((IDisposable)val)?.Dispose();
				}
				downloadFile(dir, url, fileName, fileHash, verName);
				return;
			}
			string a = "";
			using (FileStream fileStream = new FileStream(dir + "\\" + fileName, FileMode.Open))
			{
				BufferedStream val2 = new BufferedStream((Stream)fileStream);
				try
				{
					SHA1Managed val3 = new SHA1Managed();
					try
					{
						byte[] array = ((HashAlgorithm)val3).ComputeHash((Stream)(object)val2);
						StringBuilder stringBuilder = new StringBuilder(2 * array.Length);
						byte[] array2 = array;
						foreach (byte b in array2)
						{
							stringBuilder.AppendFormat("{0:x2}", b);
						}
						a = stringBuilder.ToString();
					}
					finally
					{
						((IDisposable)val3)?.Dispose();
					}
				}
				finally
				{
					((IDisposable)val2)?.Dispose();
				}
			}
			if (a == fileHash)
			{
				Console.set_ForegroundColor((ConsoleColor)10);
				Console.WriteLine("Dowloaded!");
				Console.set_ForegroundColor((ConsoleColor)7);
			}
			else
			{
				Console.set_ForegroundColor((ConsoleColor)12);
				Console.WriteLine("Error! Attempting again!");
				Console.set_ForegroundColor((ConsoleColor)7);
				File.Delete(dir + "\\" + fileName);
				downloadFile(dir, url, fileName, fileHash, verName);
			}
		}
	}
}
